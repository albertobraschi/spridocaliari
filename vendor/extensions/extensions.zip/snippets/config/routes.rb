# Put your extension routes here.

 map.namespace :admin do |admin|
   admin.resources :snippets
 end  
