module SnippetHelper
end
