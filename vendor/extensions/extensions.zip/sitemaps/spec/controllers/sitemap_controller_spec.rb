require File.dirname(__FILE__) + '/../spec_helper'

describe SitemapController do

  #Delete this example and add some real ones
  it "should use SitemapController" do
    controller.should be_an_instance_of(SitemapController)
  end

end
