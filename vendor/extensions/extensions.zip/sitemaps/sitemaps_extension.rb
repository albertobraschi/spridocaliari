# Uncomment this if you reference any of your controllers in activate
# require_dependency 'application'

class SitemapsExtension < Spree::Extension
  version "1.0"
  description "Sitemaps for Spree (html, xml, txt). Link added to footer partial."
  url "http://spreehq.org/"

  def activate
  end
end
