require File.dirname(__FILE__) + '/../spec_helper'

describe EmailSenderController do

  #Delete this example and add some real ones
  it "should use EmailSenderController" do
    controller.should be_an_instance_of(EmailSenderController)
  end

end
