class ProductLightboxHooks < Spree::ThemeSupport::HookListener
end
