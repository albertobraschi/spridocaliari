class ThemeDefaultHooks < Spree::ThemeSupport::HookListener
end
